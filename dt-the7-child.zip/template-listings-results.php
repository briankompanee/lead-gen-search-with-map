<?php
/*
Template Name: Listings Search Results
*/

// File Security Check
if ( ! defined( 'ABSPATH' ) ) { exit; }

//do_action("search_filter_query_posts", 2751);

$config = presscore_config();
//$config->set( 'template', 'page' );
//$config->set( 'template', 'archive' );
//$config->set( 'layout', 'masonry' );
$config->set( 'template', 'blog' );
$config->set( 'template.layout.type', 'masonry' );

// add content controller
add_action( 'presscore_before_main_container', 'presscore_page_content_controller', 15 );

get_header();

if ( presscore_is_content_visible() ): ?>
  <div id="content" class="content" role="main">

    <?php
    $entry_id = $_GET['entryid'];
    $entry = GFAPI::get_entry( $entry_id );

?>
<div class="deal-finder-entry">
  <strong>Name:&nbsp;</strong><?php echo rgar( $entry, '106.3' ); ?>&nbsp;<strong></strong><?php echo rgar( $entry, '106.6' ); ?><br />
  <strong>Company:&nbsp;</strong><?php echo rgar( $entry, '107' ); ?><br />
  <strong>Title:&nbsp;</strong><?php echo rgar( $entry, '108' ); ?><br />
  <strong>Email:&nbsp;</strong><?php echo rgar( $entry, '109' ); ?><br />
  <strong>Phone:&nbsp;</strong><?php echo rgar( $entry, '110' ); ?>
</div>

  <?php
			if ( have_posts() ) : while ( have_posts() ) : the_post(); // main loop

				do_action( 'presscore_before_loop' );

				if ( post_password_required() ) {
					the_content();
				} else {
					// backup config
					$config_backup = $config->get();

					presscore_display_posts_filter( array(
						'post_type' => 'post',
						'taxonomy' => 'category'
					) );

					// fullwidth wrap open
					if ( $config->get( 'full_width' ) ) { echo '<div class="full-width-wrap">'; }
					//echo '<div class="full-width-wrap">';

					$container_class = array( 'wf-container' );
					if ( $config->get( 'post.fancy_date.enabled' ) ) {
						$container_class[] = presscore_blog_fancy_date_class();
					}

          the_content();

					// fullwidth wrap close
					if ( $config->get( 'full_width' ) ) { echo '</div>'; }

					presscore_complex_pagination( $query );

					// restore config
					$config->reset( $config_backup );
				}

				do_action( 'presscore_after_loop' );

				presscore_display_share_buttons_for_post( 'page' );

			endwhile; endif;

		do_action('presscore_after_content');
		?>

  </div><!-- #content -->

  <?php endif; // if content visible ?>

<?php get_footer(); ?>