<?php

//Redirect Attendee Submissions to search & filter query string

add_filter( 'gform_confirmation_11', 'gforms_confirmation_dynamic_redirect', 10, 4 );
function gforms_confirmation_dynamic_redirect( $confirmation, $form, $entry, $ajax ) {

  $price_range                          = 165;
  $region                               = 135;

  $eastern_and_appalachia_region_areas  = 137;
  $eastern_and_appalachia_region_basins = 138;
  $eastern_and_appalachia_region_plays  = 139;

  $gulf_of_mexico_region_areas          = 140;

  $gulf_coast_areas                     = 141;
  $gulf_coast_basins                    = 142;
  $gulf_coast_plays                     = 143;

  $areas_ark_la_tex_areas               = 144;
  $areas_ark_la_tex_basins              = 145;
  $areas_ark_la_tex_plays               = 146;

  $midcon_areas                         = 147;
  $midcon_basins                        = 145;

  $permian_basin_areas                  = 149;
  $permian_basin_basins                 = 150;
  $permian_basin_plays                  = 151;

  $rockies_dakotas_four_corners_areas   = 152;
  $rockies_dakotas_four_corners_basins  = 153;
  $rockies_dakotas_four_corners_plays   = 154;

  $west_coast_areas                     = 155;
  $west_coast_basins                    = 156;
  $west_coast_plays                     = 157;

  $alaska_areas                         = 160;

  $canada_areas                         = 162;

  $international_areas                  = 163;


  if (!empty( rgar( $entry, $price_range ))) {
    $field_id = $price_range; // Update this number to your field id number
  }

 // elseif (!empty( $region ) || !empty( $eastern_and_appalachia_region_areas )) {
 //   $field_ids = array(135, 137); // Update this number to your field id number
 // }


  if ( !is_array($field_ids)){
    foreach ( $field_ids as $field_id ) {
      $field = RGFormsModel::get_field( $form, $field_id );
      $field_selected = is_object( $field ) ? $field->get_value_export( $entry ) : '';
      $field_selected_array = explode(", ", $field_selected);
      $field_selected_string = implode("-,-", $field_selected_array);
      $field_selected_url = rawurlencode($field_selected_string);
    }
  }else{
    $field = RGFormsModel::get_field( $form, $field_id );
    $field_selected = is_object( $field ) ? $field->get_value_export( $entry ) : '';
    $field_selected_array = explode(", ", $field_selected);
    $field_selected_string = implode("-,-", $field_selected_array);
    $field_selected_url = rawurlencode($field_selected_string);
  }

  $confirmation_message  = 'Thank you for submitting.<br>When we get closer to the event we will email you with your listings.<br>';
  $confirmation_redirect = 'https://www.navigatenape.com/?sfid=2751&_sfm_exhibitor_region=' . $field_selected_url;
  $confirmation  = '<div id="overlay"><div id="gform-notification">' . $confirmation_message . '<a class="button" href="' . $confirmation_redirect . '">OK</a></div></div>';

  return $confirmation;

}
add_filter( 'wp_footer', 'gf_popoup_overlay');
function gf_popoup_overlay() {
	//echo '<div id="overlay"></div>';
	echo '
		<script type="text/javascript">
			jQuery("body").addClass("message-sent");
			jQuery("#gform-notification a").click(function() {
				jQuery("#overlay, #gform-notification").fadeOut("normal", function() {
					$(this).remove();
				});
			});
		</script>
	';
}