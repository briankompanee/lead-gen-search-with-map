<?php
/**
 * Blog post template for masonry layout PRINTING ONLY.
 */

// File Security Check.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Remove presscore_the_excerpt() filter.
remove_filter( 'presscore_post_details_link', 'presscore_return_empty_string', 15 );

$config = presscore_config();

$post_class = array( 'post' );
if ( ! has_post_thumbnail() ) {
	$post_class[] = 'no-img';
}
?>

<?php// do_action( 'presscore_before_post' ); ?>

		<li class="listings-print print-hide">
			<h3 class="entry-title"><a href="<?php the_permalink(); ?>" title="<?php echo the_title_attribute( 'echo=0' ); ?>" rel="bookmark"><?php the_title(); ?></a></h3>

			<?php

			//echo presscore_get_posted_on();

      //Booth
      $exhibitor_booth_number_2 = get_field_object('exhibitor_booth_number_2');

      // vars
      $exhibitor_price_range = get_field('exhibitor_price_range');
      $exhibitor_region      = get_field('exhibitor_region');

      $exhibitor_eastern_and_appalachia_region_area = get_field('exhibitor_eastern_and_appalachia_region_area');
      $exhibitor_basins_eastern_appalachia_region = get_field('exhibitor_basins_eastern_appalachia_region');
      $exhibitor_plays_eastern_appalachia = get_field('exhibitor_plays_eastern_appalachia');

      $exhibitor_areas_gulf_of_mexico = get_field('exhibitor_areas_gulf_of_mexico');

      $exhibitor_areas_gulf_coast_region = get_field('exhibitor_areas_gulf_coast_region');
      $exhibitor_basins_gulf_coast_region = get_field('exhibitor_basins_gulf_coast_region');
      $exhibitor_plays_gulf_coast_region = get_field('exhibitor_plays_gulf_coast_region');

      $exhibitor_areas_ark_la_tex_region = get_field('exhibitor_areas_ark_la_tex_region');
      $exhibitor_basins_ark_la_tex_region = get_field('exhibitor_basins_ark_la_tex_region');
      $exhibitor_plays_ark_la_tex_region = get_field('exhibitor_plays_ark_la_tex_region');

      $exhibitor_areas_midcon_region = get_field('exhibitor_areas_midcon_region');
      $exhibitor_basins_midcon_region = get_field('exhibitor_basins_midcon_region');

      $exhibitor_areas_permian_basin_region = get_field('exhibitor_areas_permian_basin_region');
      $exhibitor_basins_permian_basin_region = get_field('exhibitor_basins_permian_basin_region');
      $exhibitor_plays_permian_basin_region = get_field('exhibitor_plays_permian_basin_region');

      $exhibitor_areas_rockies_dakotas_four_corners_region = get_field('exhibitor_areas_rockies_dakotas_four_corners_region');
      $exhibitor_basins_rockies_dakotas_four_corners_region = get_field('exhibitor_basins_rockies_dakotas_four_corners_region');
      $exhibitor_plays_rockies_dakotas_four_corners_region = get_field('exhibitor_plays_rockies_dakotas_four_corners_region');

      $exhibitor_areas_west_coast_region = get_field('exhibitor_areas_west_coast_region');
      $exhibitor_basins_west_coast_region = get_field('exhibitor_basins_west_coast_region');
      $exhibitor_plays_west_coast_region = get_field('exhibitor_plays_west_coast_region');

      $exhibitor_areas_alaska_region = get_field('exhibitor_areas_alaska_region');

      $exhibitor_areas_canada_province = get_field('exhibitor_areas_canada_province');

      $exhibitor_areas_international_country = get_field('exhibitor_areas_international_country');

      $exhibitor_listing_type = get_field('exhibitor_listing_type');


      // check

      if( $exhibitor_booth_number_2 ){
        echo '<p><strong>' . $exhibitor_booth_number_2['label'] . ':</strong> ' . $exhibitor_booth_number_2['value'] . '</p>';
      }

      if( $exhibitor_price_range ){
        echo '<p><strong>Price Range:</strong> ' . $exhibitor_price_range . '</p>';
      }

      if( $exhibitor_region ){
        echo '<p><strong>Region:</strong> ' . $exhibitor_region . '</p>';
      }

      if( $exhibitor_eastern_and_appalachia_region_area ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_eastern_and_appalachia_region_area . '</p>';
      }
      /*
      if( $exhibitor_basins_eastern_appalachia_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_eastern_appalachia_region . '</p>';
      }
      if( $exhibitor_plays_eastern_appalachia ){
        echo '<p><strong>Play:</strong> ' . $exhibitor_plays_eastern_appalachia . '</p>';
      }
      */

      if( $exhibitor_areas_gulf_of_mexico ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_gulf_of_mexico . '</p>';
      }
      if( $exhibitor_areas_gulf_coast_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_gulf_coast_region . '</p>';
      }
      /*
      if( $exhibitor_basins_gulf_coast_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_gulf_coast_region . '</p>';
      }
      */
      if( $exhibitor_areas_ark_la_tex_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_ark_la_tex_region . '</p>';
      }
      /*
      if( $exhibitor_basins_ark_la_tex_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_ark_la_tex_region . '</p>';
      }
      if( $exhibitor_plays_ark_la_tex_region ){
        echo '<p><strong>Play:</strong> ' . $exhibitor_plays_ark_la_tex_region . '</p>';
      }
      */
      if( $exhibitor_areas_midcon_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_midcon_region . '</p>';
      }
      /*
      if( $exhibitor_basins_midcon_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_midcon_region . '</p>';
      }
      */
      if( $exhibitor_areas_permian_basin_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_permian_basin_region . '</p>';
      }
      /*
      if( $exhibitor_basins_permian_basin_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_permian_basin_region . '</p>';
      }
      */
      if( $exhibitor_areas_rockies_dakotas_four_corners_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_rockies_dakotas_four_corners_region . '</p>';
      }
      /*
      if( $exhibitor_basins_rockies_dakotas_four_corners_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_rockies_dakotas_four_corners_region . '</p>';
      }
      if( $exhibitor_plays_rockies_dakotas_four_corners_region ){
        echo '<p><strong>Play:</strong> ' . $exhibitor_plays_rockies_dakotas_four_corners_region . '</p>';
      }
      */
      if( $exhibitor_areas_alaska_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_alaska_region . '</p>';
      }
      if( $exhibitor_areas_canada_province ){
        echo '<p><strong>Province:</strong> ' . $exhibitor_areas_canada_province . '</p>';
      }
      if( $exhibitor_areas_international_country ){
        echo '<p><strong>Country:</strong> ' . $exhibitor_areas_international_country . '</p>';
      }
      if( $exhibitor_listing_type ){
        echo '<p><strong>Listing Type:</strong> ' . $exhibitor_listing_type . '</p>';
      }
      /*
			if ( $config->get( 'show_excerpts' ) ) {
				presscore_the_excerpt();
			}

			if ( $config->get( 'show_details' ) ) {
				echo presscore_post_details_link();
			}
      */
			echo presscore_post_edit_link();
			?>

		</li>

<?php // do_action( 'presscore_after_post' ); ?>