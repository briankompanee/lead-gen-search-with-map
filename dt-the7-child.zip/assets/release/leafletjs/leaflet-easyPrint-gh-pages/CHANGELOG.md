# Changelog


## Version 2.1.0
1/08/2017
- Fix for page title on print
- Support for custom page title
- Support for custom css spinner
- Support for custom color on spinner bg
- Support for filename for programmatic printing


## Version 2
22/07/2017
- Complete overhaul
- Now using the excellent dom-to-image library
- Ability to both print and export
- Programmatic access
- Resizing 
