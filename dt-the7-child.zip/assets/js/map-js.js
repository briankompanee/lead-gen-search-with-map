
  var map = L.map('mapid', {
      crs: L.CRS.Simple,
      zoomControl: false,
      maxZoom: 2,
      minZoom: -3
  });
  var bounds = [[0,0], [1414,5581]];
  var image = L.imageOverlay(<?php echo json_encode(get_stylesheet_directory_uri() . '/images/floorplan-nape-2019.png'); ?>, bounds).addTo(map);
  map.fitBounds(bounds);

  var SVGOverlay = L.ImageOverlay.extend({
      options: {
      },

      _initImage: function () {
          var wasElementSupplied = this._url.tagName.toLowerCase() === 'svg';
          var svg = this._image = wasElementSupplied ? this._url : L.DomUtil.create('svg');
     }
  });

  var svg = document.getElementById('src').content.querySelector('svg');
  var overlay = new SVGOverlay(svg, bounds).addTo(map);

  var boothArrayIDs = <?php echo json_encode($booths_selected_ids); ?>;
  var boothIDs = boothArrayIDs.join(", ");

  //Highlight Booth SVG Rectangle
  var rectangles = svg.querySelectorAll(boothIDs);

  //Array.prototype.forEach.call(rectangles, function(rectangle, index) {
  [...rectangles].forEach(rectangle => {
    rectangle.removeAttribute('style');
    rectangle.setAttribute('class', 'active-booth');
  });

  // zoom control
  map.addControl(new L.Control.ZoomMin({
      position: 'topright',
      useMinZoom: false,
      floorplanBounds: map.getBounds(),
      useFloorplanBoundsZoom: true
  }));