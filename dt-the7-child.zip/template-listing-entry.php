<?php
/*
Template Name: Listing Entry
*/
if ( is_user_logged_in() || current_user_can('publish_posts') ) { // Execute code if user is logged in
    acf_form_head();
    wp_deregister_style( 'wp-admin' );
}

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$config = presscore_config();
$config->set( 'template', 'page' );

get_header();
?>

<?php if ( presscore_is_content_visible() ): ?>

    <div id="content" class="content" role="main">

		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				do_action( 'presscore_before_loop' );
				//the_content();

        if ( ! ( is_user_logged_in() || current_user_can('publish_posts') ) ) {
            echo '<p>You must be a registered author to post.</p>';
        } else {
             acf_form(array(
                 'post_id' => 'new_post',
                 'field_groups' => array(2654,2541), // Used ID of the field groups here.
                 'post_title' => true, // This will show the title filed
                 'post_content' => true, // This will show the content field
                 'form' => true,
                 'new_post' => array(
                     'post_type' => 'listings',
                     'post_status' => 'publish' // You may use other post statuses like draft, private etc.
                 ),
                 'return' => '%post_url%',
                 'submit_value' => 'Submit Listing',
             ));
        }
				wp_link_pages( array(
					'before' => '<div class="page-links">' . __( 'Pages:', 'the7mk2' ),
					'after'  => '</div>',
				) );
				presscore_display_share_buttons_for_post( 'page' );
				comments_template( '', true );
			}
		} else {
			get_template_part( 'no-results', 'page' );
		}
		?>

    </div><!-- #content -->

	<?php do_action( 'presscore_after_content' ) ?>

<?php endif // if content visible ?>

<?php get_footer() ?>