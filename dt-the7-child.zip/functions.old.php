<?php
/**
 * Proper way to enqueue scripts and styles.
 */
function wpdocs_theme_name_scripts() {

  if (is_page( 'Map' ) || is_page_template( 'template-listings-results.php' ) ){

    wp_enqueue_style( 'css-leaflet', get_stylesheet_directory_uri() . '/assets/release/leafletjs/leaflet.css');
    wp_enqueue_style( 'css-leaflet-zoom-min', get_stylesheet_directory_uri() . '/assets/release/leafletjs/leaflet-zoom-min/L.Control.ZoomMin.css');
    wp_enqueue_style( 'css-print', get_stylesheet_directory_uri() . '/assets/css/print.css', array(), '0.1.0', 'print');

    //wp_register_script( 'jquery3.2.1', 'https://code.jquery.com/jquery-3.2.1.min.js' );
    //wp_add_inline_script( 'jquery3.2.1', 'var jQuery3_2_1 = $.noConflict(true);' );
    //wp_enqueue_script( 'plugin-javascript', plugins_url( 'js.js', __FILE__ ), array( 'jquery3.2.1' ) );

    wp_enqueue_script( 'js-leaflet', get_stylesheet_directory_uri() . '/assets/release/leafletjs/leaflet.js', array(), true );

    //wp_enqueue_script( 'js-browser-print', get_stylesheet_directory_uri() . '/assets/release/leafletjs/leaflet-browser-print/dist/leaflet.browser.print.min.js', array(), true );
   // wp_enqueue_script( 'js-easyPrint', get_stylesheet_directory_uri() . '/assets/release/leafletjs/leaflet-easyPrint-gh-pages/dist/bundle.js');
    wp_enqueue_script( 'js-leaflet-zoom-min', get_stylesheet_directory_uri() . '/assets/release/leafletjs/leaflet-zoom-min/L.Control.ZoomMin.js', array(), true );
    //wp_enqueue_script( 'js-mapjs', get_stylesheet_directory_uri() . '/assets/js/map-js.js', array(), true );
  }
}
add_action( 'wp_enqueue_scripts', 'wpdocs_theme_name_scripts' );

// Listing custom post type function
function create_posttype() {
  register_post_type( 'listings',
    // CPT Options
    array(
      'labels' => array(
        'name' => __( 'Listings' ),
        'singular_name' => __( 'Listing' )
      ),
      'public' => true,
      'has_archive' => true,
      'rewrite' => array('slug' => 'listings'),
      'supports' => array( 'title', 'editor', 'author'),
    )
  );
}
add_action( 'init', 'create_posttype' );

//ACF code required to edit custom fields on front end and use ACF forms
function yourfunction_add_acf_header() {
  acf_form_head();
}
add_action( 'wp_head', 'yourfunction_add_acf_header', 0 );

// Shortcode to output custom code to show users listings in Visual Composer
function wpc_vc_shortcode( $atts ) {
  if ( ! ( is_user_logged_in() || current_user_can('publish_posts') ) ) {
    echo '<p>You must be a registered Exhibitor to post a Listing.</p>';
  } else {
    //global $current_user;
    $current_user = wp_get_current_user();
    $author_query = array('posts_per_page' => '-1','author' => $current_user->ID, 'post_type' => 'listings');
    $author_posts = new WP_Query($author_query);
    //echo 'User ID: ' . $current_user->ID . '<br />';
    $user_booth_number = get_field('field_5c3ccbfcccb41', 'user_'. $current_user->ID);
    echo 'Booth: ' . $user_booth_number . '<br />';
?>
  <ol>
  <?php
    while($author_posts->have_posts()) : $author_posts->the_post();
  ?>
    <li><?php the_title(); ?>&nbsp;<a class='post-edit-button' href="<?php echo get_permalink() ?>?action=edit">View/Edit Listing</a></li>
  <?php
    endwhile;
  ?>
  </ol>
  <?php
  }
}
add_shortcode( 'my_listing_output', 'wpc_vc_shortcode');

//Output all ACF fields for Field group 2541
function get_exhibitor_fields() {
  global $post;

  $exhibitor_group_id = 2541; // Post ID of the exhibitor field group.
  $exhibitor_fields = array();

  $fields = acf_get_fields( $exhibitor_group_id );

  foreach ( $fields as $field ) {
    $field_value = get_field( $field['name'] );

    if ( $field_value && !empty( $field_value ) ) {
      $exhibitor_fields[$field['name']] = $field;
      $exhibitor_fields[$field['name']]['value'] = $field_value;
    }
  }

  return $exhibitor_fields;

}

//Map User Booth# field to Listing Booth# gravity form.
add_filter( 'gform_field_value_booth_number', 'populate_booth_number' );
function populate_booth_number( $value ) {
  $user_id = get_current_user_id();
  $value = get_field('exhibitor_booth_number', 'user_'. $user_id);
   return $value;
}

//Map User Booth# field to Listing Booth# field based on author of listing.

/*
add_action('acf/save_post', 'update_name_provider_field', 20);
function update_name_provider_field($post_id) {


    $post_author_id = get_post_field( 'post_author', $post_id );
    $user_booth_number = get_field('field_5c3ccbfcccb41', 'user_'. $post_author_id);
    // use the acf field key here
    update_field('field_5c3fe8decdaf9', $user_booth_number, $post_id);

}
*/
add_filter('acf/load_value/key=field_5c3fe8decdaf9', 'my_acf_load_value', 10, 3);
function my_acf_load_value( $value, $post_id) {

//$exhibitor_booth_number_2 = get_field('exhibitor_booth_number_2');
$post_author_id = get_post_field( 'post_author', $post_id );

if(!$value){

    $value = get_field('exhibitor_booth_number', 'user_'. $post_author_id);
    return $value;
  }else{
    return $value;
  }

}

//Remove "Private: " from titles
function remove_private_prefix($title) {
  $title = str_replace('Private: ', '', $title);
  return $title;
}
add_filter('the_title', 'remove_private_prefix');

//Exhibitor Listing Submission - Update Checkbox Fields
add_action("gform_after_submission_1", "acf_post_submission_listing", 10, 2);
function acf_post_submission_listing ($entry, $form) {
   $post_id = $entry["post_id"];
   //methods used to define - Checkbox
   $checkbox_listingd_1_values = get_post_custom_values("exhibitor_listing_check_all_methods_that_apply", $post_id);
   update_field("field_5c3d98237700b", $checkbox_listingd_1_values, $post_id);
}

//Allow logout without confirmation
add_action('check_admin_referer', 'logout_without_confirm', 10, 2);
function logout_without_confirm($action, $result) {
  if ($action == "log-out" && !isset($_GET['_wpnonce'])) {
    $redirect_to = isset($_REQUEST['redirect_to']) ? $_REQUEST['redirect_to'] : home_url();
    $location = str_replace('&amp;', '&', wp_logout_url($redirect_to));
    header("Location: $location");
    die;
  }
}

//allow you to add .csv files to be uploaded
add_filter( 'mime_types', 'wpse_mime_types' );
function wpse_mime_types( $existing_mimes ) {
  // Add csv to the list of allowed mime types
  $existing_mimes['csv'] = 'text/csv';

  return $existing_mimes;
}

/**
 * Remove menu items from particular user caps
 */
function remove_by_cap_admin_menu() {
if ( !is_admin())
        return;
    if ( !current_user_can('update_core') ) {
      remove_menu_page( 'edit.php?post_type=page' );
      remove_menu_page( 'edit.php' );                       //Posts
      remove_menu_page( 'upload.php' );                     //Media
      remove_menu_page( 'edit-comments.php' );              //Comments
      remove_menu_page( 'themes.php' );                     //Appearance
      remove_menu_page( 'users.php' );                      //Users
      remove_menu_page( 'tools.php' );                    //Tools
      remove_menu_page( 'options-general.php' );            //Settings
      remove_menu_page( 'edit.php?post_type=dt_gallery' );  //Photo Albums
      remove_menu_page( 'edit.php?post_type=dt_slideshow' );
      remove_menu_page( 'edit.php?post_type=dt_team' );
      remove_menu_page( 'edit.php?post_type=dt_testimonials' );
      remove_menu_page( 'edit.php?post_type=dt_portfolio' );
      remove_menu_page( 'wpcf7' );
      remove_menu_page( 'edit.php?post_type=popup' );
      remove_menu_page( 'vc-general' );                           //vc bakery
      remove_menu_page( 'wpengine-common' );                      //Wp Engine
      remove_menu_page( 'edit.php?post_type=acf-field-group' );   //Custom Fields
      remove_menu_page( 'revslider' );                            //The7 Slider Revolution
      remove_menu_page( 'go-pricing' );                           //The7 Go Pricing
      remove_menu_page( 'edit.php?post_type=search-filter-widget' ); //Search & Filter
      remove_menu_page( 'about-ultimate' );                           //The7 Ultimate
    }
}
add_action('admin_init', 'remove_by_cap_admin_menu', 999);



/**
 * Add menu items from particular user caps

add_action( 'admin_menu', 'add_by_cap_admin_menu' );
function add_by_cap_admin_menu() {

  if ( !current_user_can('update_core') ) {
    $capabilities = 'manage_options';
    add_menu_page(
    __('Manage Exports', 'wp_all_export_plugin') . ' &lsaquo; ' . __('WP All Export', 'wp_all_export_plugin'),
    __('Manage Exports', 'wp_all_export_plugin'),
    PMXE_Plugin::$capabilities,
    'pmxe-admin-manage',
    array(PMXE_Plugin::getInstance(), 'adminDispatcher')
    );
  }
}
*/

//Redirect Attendee Submissions to search & filter query string
add_filter( 'gform_confirmation_3', 'gforms_confirmation_dynamic_redirect', 10, 4 );
function gforms_confirmation_dynamic_redirect( $confirmation, $form, $entry, $ajax ) {

  $price_range                          = 165;
  $region                               = 135;

  $eastern_and_appalachia_region_areas  = 137;
  $eastern_and_appalachia_region_basins = 138;
  $eastern_and_appalachia_region_plays  = 139;

  $gulf_of_mexico_region_areas          = 140;

  $gulf_coast_areas                     = 141;
  $gulf_coast_basins                    = 142;
  $gulf_coast_plays                     = 143;

  $areas_ark_la_tex_areas               = 144;
  $areas_ark_la_tex_basins              = 145;
  $areas_ark_la_tex_plays               = 146;

  $midcon_areas                         = 147;
  $midcon_basins                        = 145;

  $permian_basin_areas                  = 149;
  $permian_basin_basins                 = 150;
  $permian_basin_plays                  = 151;

  $rockies_dakotas_four_corners_areas   = 152;
  $rockies_dakotas_four_corners_basins  = 153;
  $rockies_dakotas_four_corners_plays   = 154;

  $west_coast_areas                     = 155;
  $west_coast_basins                    = 156;
  $west_coast_plays                     = 157;

  $alaska_areas                         = 160;

  $canada_areas                         = 162;

  $international_areas                  = 163;

  $field_answer  ='';

  if (!empty( rgar( $entry, $price_range ))) {
    $field_id     = $price_range;
    $field_name   = '&_sfm_exhibitor_price_range=';
    $field_ids[]  = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $region ))) {
    $field_id     = $region;
    $field_name   = '&_sfm_exhibitor_region=';
    $field_ids[]  = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $eastern_and_appalachia_region_areas ))) {
    $field_id     = $eastern_and_appalachia_region_areas;
    $field_name   = '&_sfm_exhibitor_eastern_and_appalachia_region_area=';
    $field_ids[]  = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $eastern_and_appalachia_region_basins ))) {
    $field_id     = $eastern_and_appalachia_region_basins;
    $field_name   = '&_sfm_exhibitor_basins_eastern_appalachia_region=';
    $field_ids[]  = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $eastern_and_appalachia_region_plays ))) {
    $field_id     = $eastern_and_appalachia_region_plays;
    $field_name   = '&_sfm_exhibitor_plays_eastern_appalachia=';
    $field_ids[]  = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $gulf_of_mexico_region_areas ))) {
    $field_id     = $gulf_of_mexico_region_areas;
    $field_name   = '&_sfm_exhibitor_areas_gulf_of_mexico=';
    $field_ids[]  = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $gulf_coast_areas ))) {
    $field_id     = $gulf_coast_areas;
    $field_name   = '&_sfm_exhibitor_areas_gulf_coast_region=';
    $field_ids[]  = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $gulf_coast_basins ))) {
    $field_id    = $gulf_coast_basins;
    $field_name  = '&_sfm_exhibitor_basins_gulf_coast_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $gulf_coast_plays ))) {
    $field_id    = $gulf_coast_plays;
    $field_name  = '&_sfm_exhibitor_plays_gulf_coast_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $areas_ark_la_tex_areas ))) {
    $field_id    = $areas_ark_la_tex_areas;
    $field_name  = '&_sfm_exhibitor_areas_ark_la_tex_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $areas_ark_la_tex_basins ))) {
    $field_id    = $areas_ark_la_tex_basins;
    $field_name  = '&_sfm_exhibitor_basins_ark_la_tex_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $areas_ark_la_tex_plays ))) {
    $field_id    = $areas_ark_la_tex_plays;
    $field_name  = '&_sfm_exhibitor_plays_ark_la_tex_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $midcon_areas ))) {
    $field_id    = $midcon_areas;
    $field_name  = '&_sfm_exhibitor_areas_midcon_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $midcon_basins ))) {
    $field_id    = $midcon_basins;
    $field_name  = '&_sfm_exhibitor_basins_midcon_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $permian_basin_areas ))) {
    $field_id    = $permian_basin_areas;
    $field_name  = '&_sfm_exhibitor_areas_permian_basin_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $permian_basin_basins ))) {
    $field_id    = $permian_basin_basins;
    $field_name  = '&_sfm_exhibitor_basins_permian_basin_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $permian_basin_plays ))) {
    $field_id    = $permian_basin_plays;
    $field_name  = '&_sfm_exhibitor_plays_permian_basin_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $rockies_dakotas_four_corners_areas ))) {
    $field_id    = $rockies_dakotas_four_corners_areas;
    $field_name  = '&_sfm_exhibitor_areas_rockies_dakotas_four_corners_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $rockies_dakotas_four_corners_basins ))) {
    $field_id    = $rockies_dakotas_four_corners_basins;
    $field_name  = '&_sfm_exhibitor_basins_rockies_dakotas_four_corners_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $rockies_dakotas_four_corners_plays ))) {
    $field_id    = $rockies_dakotas_four_corners_plays;
    $field_name  = '&_sfm_exhibitor_plays_rockies_dakotas_four_corners_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $west_coast_areas ))) {
    $field_id    = $west_coast_areas;
    $field_name  = '&_sfm_exhibitor_areas_west_coast_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $west_coast_basins ))) {
    $field_id    = $west_coast_basins;
    $field_name  = '&_sfm_exhibitor_basins_west_coast_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $west_coast_plays ))) {
    $field_id    = $west_coast_plays;
    $field_name  = '&_sfm_exhibitor_plays_west_coast_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $alaska_areas ))) {
    $field_id    = $alaska_areas;
    $field_name  = '&_sfm_exhibitor_areas_alaska_region=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $canada_areas ))) {
    $field_id    = $canada_areas;
    $field_name  = '&_sfm_exhibitor_areas_canada_province=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  if (!empty( rgar( $entry, $international_areas ))) {
    $field_id    = $international_areas;
    $field_name  = '&_sfm_exhibitor_areas_international_country=';
    $field_ids[] = array("id" => $field_id, "url" => $field_name);
  }

  foreach ( $field_ids as $field_id ) {


        $field           = RGFormsModel::get_field( $form, $field_id['id'] );
        $field_selected  = is_object( $field ) ? $field->get_value_export( $entry ) : '';

        $field_selected_array = explode(", ", $field_selected);
        $field_selected_string = implode("-,-", $field_selected_array);

        $field_url = $field_id['url'] . rawurlencode($field_selected_string);
        $field_query_string_complete .= $field_url;

  }
        $url = home_url() . '?sfid=2751' . $field_query_string_complete;

      global $wpdb;

    	// add form URL data to custom database table
      $wpdb->insert(
  	    'wp_gf_entry_meta',
  	    array(
  	      'form_id' => 3,
  	      'entry_id' => $entry['id'],
  	      'meta_key' => 134,
  	      'meta_value' => $url
  	    )
  	);
/*
  $confirmation_message  = 'Thank you for submitting.<br>When we get closer to the event we will email you with your listings.<br>';
  $confirmation_redirect =  $url;
  $confirmation  = '<div id="overlay"><div id="gform-notification">' . $confirmation_message . '<a class="button" href="' . $confirmation_redirect . '">OK</a></div></div>';
*/
  $confirmation = array( 'redirect' => home_url('/') . 'find-deals/submission-received/');

  //$confirmation = array( 'redirect' => $url );

  return $confirmation;

}

//Gravity Forms Popup JS for Attendee submission - add to footer
add_filter( 'wp_footer', 'gf_popoup_overlay');
function gf_popoup_overlay() {
	//echo '<div id="overlay"></div>';
	echo '
		<script type="text/javascript">
			jQuery("body").addClass("message-sent");
			jQuery("#gform-notification a").click(function() {
				jQuery("#overlay, #gform-notification").fadeOut("normal", function() {
					$(this).remove();
				});
			});
		</script>
	';
}