<?php
/**
 * Single Listing content template.
 *
 * @package The7
 * @since 1.0.0
 */
$current_user = wp_get_current_user();
if ( ( is_user_logged_in() && $current_user->ID == $post->post_author ) ) { // Execute code if user is logged in or user is the author
    acf_form_head();
    wp_deregister_style( 'wp-admin' );
}

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $post;

$config = presscore_config();

$post_classes = array();
if ( $config->get_bool( 'post.fancy_date.enabled' ) ) {
	$post_classes[] = presscore_blog_fancy_date_class();
}
?>

<article id="post-<?php the_ID() ?>" <?php post_class( $post_classes ) ?>>

	<?php
	do_action( 'presscore_before_post_content' );

	// Post featured image.
    presscore_get_template_part( 'theme', 'single-post/post-featured-image' );

	// Post content.
	echo '<div class="entry-content">';

    if ( isset($_GET['action'])  && $_GET['action'] === 'edit' ) {?>
      <div class="acf-edit-post">
        <?php
        if ( ( is_user_logged_in() && $current_user->ID == $post->post_author ) ) {
          echo "<div class='acf-edit-post'>";
            acf_form (array(
              'field_groups' => array(2720,2541), // Same ID(s) used before
              'form' => true,
              'return' => '%post_url%',
              'submit_value' => 'Save Changes',
              'post_title' => true,
              'post_content' => false,
            ));
          echo "</div>";
        }
        ?>
      </div>
    <?php
    }else{

      //Booth
      $exhibitor_booth_number_2 = get_field_object('exhibitor_booth_number_2');

      // vars
      $exhibitor_price_range = get_field('exhibitor_price_range');
      $exhibitor_region      = get_field('exhibitor_region');

      $exhibitor_eastern_and_appalachia_region_area = get_field('exhibitor_eastern_and_appalachia_region_area');
      $exhibitor_basins_eastern_appalachia_region = get_field('exhibitor_basins_eastern_appalachia_region');
      $exhibitor_plays_eastern_appalachia = get_field('exhibitor_plays_eastern_appalachia');

      $exhibitor_areas_gulf_of_mexico = get_field('exhibitor_areas_gulf_of_mexico');

      $exhibitor_areas_gulf_coast_region = get_field('exhibitor_areas_gulf_coast_region');
      $exhibitor_basins_gulf_coast_region = get_field('exhibitor_basins_gulf_coast_region');
      $exhibitor_plays_gulf_coast_region = get_field('exhibitor_plays_gulf_coast_region');

      $exhibitor_areas_ark_la_tex_region = get_field('exhibitor_areas_ark_la_tex_region');
      $exhibitor_basins_ark_la_tex_region = get_field('exhibitor_basins_ark_la_tex_region');
      $exhibitor_plays_ark_la_tex_region = get_field('exhibitor_plays_ark_la_tex_region');

      $exhibitor_areas_midcon_region = get_field('exhibitor_areas_midcon_region');
      $exhibitor_basins_midcon_region = get_field('exhibitor_basins_midcon_region');

      $exhibitor_areas_permian_basin_region = get_field('exhibitor_areas_permian_basin_region');
      $exhibitor_basins_permian_basin_region = get_field('exhibitor_basins_permian_basin_region');
      $exhibitor_plays_permian_basin_region = get_field('exhibitor_plays_permian_basin_region');

      $exhibitor_areas_rockies_dakotas_four_corners_region = get_field('exhibitor_areas_rockies_dakotas_four_corners_region');
      $exhibitor_basins_rockies_dakotas_four_corners_region = get_field('exhibitor_basins_rockies_dakotas_four_corners_region');
      $exhibitor_plays_rockies_dakotas_four_corners_region = get_field('exhibitor_plays_rockies_dakotas_four_corners_region');

      $exhibitor_areas_west_coast_region = get_field('exhibitor_areas_west_coast_region');
      $exhibitor_basins_west_coast_region = get_field('exhibitor_basins_west_coast_region');
      $exhibitor_plays_west_coast_region = get_field('exhibitor_plays_west_coast_region');

      $exhibitor_areas_alaska_region = get_field('exhibitor_areas_alaska_region');

      $exhibitor_areas_canada_province = get_field('exhibitor_areas_canada_province');

      $exhibitor_areas_international_country = get_field('exhibitor_areas_international_country');

      $exhibitor_listing_type = get_field('exhibitor_listing_type');


      //LOCATION & GEOLOGY
      $exhibitor_listing_county_parish = get_field_object('exhibitor_listing_county_parish');
      $exhibitor_listing_street = get_field_object('exhibitor_listing_street');
      $exhibitor_listing_no_of_wells = get_field_object('exhibitor_listing_no_of_wells');
      $exhibitor_listing_well_count_potential = get_field_object('exhibitor_listing_well_count_potential');
      $exhibitor_listing_no_of_prospects = get_field_object('exhibitor_listing_no_of_prospects');
      $exhibitor_listing_acreage = get_field_object('exhibitor_listing_acreage');

      $exhibitor_listing_gross_acres = get_field_object('exhibitor_listing_gross_acres');
      $exhibitor_listing_net_acres = get_field_object('exhibitor_listing_net_acres');
      $exhibitor_listing_completion_date = get_field_object('exhibitor_listing_completion_date');
      $exhibitor_listing_api_no = get_field_object('exhibitor_listing_api_no');
      $exhibitor_listing_legal_location_tsr_section = get_field_object('exhibitor_listing_legal_location_tsr_section');
      $exhibitor_listing_field = get_field_object('exhibitor_listing_field');

      $exhibitor_listing_basin_play = get_field_object('exhibitor_listing_basin_play');
      $exhibitor_listing_basin_trend = get_field_object('exhibitor_listing_basin_trend');
      $exhibitor_listing_objective_1 = get_field_object('exhibitor_listing_objective_1');
      $exhibitor_listing_objective_1_depth_ft = get_field_object('exhibitor_listing_objective_1_depth_ft');
      $exhibitor_listing_objective_1_expected_ip = get_field_object('exhibitor_listing_objective_1_expected_ip');
      $exhibitor_listing_objective_2 = get_field_object('exhibitor_listing_objective_2');

      $exhibitor_listing_objective_2_depth_ft = get_field_object('exhibitor_listing_objective_2_depth_ft');
      $exhibitor_listing_objective_2_expected_ip = get_field_object('exhibitor_listing_objective_2_expected_ip');
      $exhibitor_listing_comments_formations = get_field_object('exhibitor_listing_comments_formations');
      $exhibitor_listing_formation_1 = get_field_object('exhibitor_listing_formation_1');
      $exhibitor_listing_formation_1_depth_ft = get_field_object('exhibitor_listing_formation_1_depth_ft');
      $exhibitor_listing_formation_2 = get_field_object('exhibitor_listing_formation_2');
      $exhibitor_listing_formation_2_depth_ft = get_field_object('exhibitor_listing_formation_2_depth_ft');



      echo '<h3>LISTING INFO</h3><hr><br>';

      if( $exhibitor_booth_number_2 ){
        echo '<p><strong>' . $exhibitor_booth_number_2['label'] . ':</strong> ' . $exhibitor_booth_number_2['value'] . '</p>';
      }
      if( $exhibitor_price_range ){
        echo '<p><strong>Price Range:</strong> ' . $exhibitor_price_range . '</p>';
      }

      echo '<h3>REGION INFO</h3><hr><br>';

      if( $exhibitor_region ){
        echo '<p><strong>Region:</strong> ' . $exhibitor_region . '</p>';
      }

      if( $exhibitor_eastern_and_appalachia_region_area ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_eastern_and_appalachia_region_area . '</p>';
      }

      if( $exhibitor_basins_eastern_appalachia_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_eastern_appalachia_region . '</p>';
      }
      if( $exhibitor_plays_eastern_appalachia ){
        echo '<p><strong>Play:</strong> ' . $exhibitor_plays_eastern_appalachia . '</p>';
      }

      if( $exhibitor_areas_gulf_of_mexico ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_gulf_of_mexico . '</p>';
      }
      if( $exhibitor_areas_gulf_coast_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_gulf_coast_region . '</p>';
      }

      if( $exhibitor_basins_gulf_coast_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_gulf_coast_region . '</p>';
      }
      if( $exhibitor_areas_ark_la_tex_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_ark_la_tex_region . '</p>';
      }

      if( $exhibitor_basins_ark_la_tex_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_ark_la_tex_region . '</p>';
      }
      if( $exhibitor_plays_ark_la_tex_region ){
        echo '<p><strong>Play:</strong> ' . $exhibitor_plays_ark_la_tex_region . '</p>';
      }

      if( $exhibitor_areas_midcon_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_midcon_region . '</p>';
      }
      if( $exhibitor_basins_midcon_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_midcon_region . '</p>';
      }

      if( $exhibitor_areas_permian_basin_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_permian_basin_region . '</p>';
      }
      if( $exhibitor_basins_permian_basin_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_permian_basin_region . '</p>';
      }

      if( $exhibitor_areas_rockies_dakotas_four_corners_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_rockies_dakotas_four_corners_region . '</p>';
      }
      if( $exhibitor_basins_rockies_dakotas_four_corners_region ){
        echo '<p><strong>Basin:</strong> ' . $exhibitor_basins_rockies_dakotas_four_corners_region . '</p>';
      }

      if( $exhibitor_plays_rockies_dakotas_four_corners_region ){
        echo '<p><strong>Play:</strong> ' . $exhibitor_plays_rockies_dakotas_four_corners_region . '</p>';
      }
      if( $exhibitor_areas_alaska_region ){
        echo '<p><strong>Area:</strong> ' . $exhibitor_areas_alaska_region . '</p>';
      }

      if( $exhibitor_areas_canada_province ){
        echo '<p><strong>Province:</strong> ' . $exhibitor_areas_canada_province . '</p>';
      }
      if( $exhibitor_areas_international_country ){
        echo '<p><strong>Country:</strong> ' . $exhibitor_areas_international_country . '</p>';
      }

      if( $exhibitor_listing_type ){
        echo '<p><strong>Listing Type:</strong> ' . $exhibitor_listing_type . '</p>';
      }


      echo '<h3>LOCATION & GEOLOGY</h3><hr><br>';

      if( $exhibitor_listing_county_parish ){
        echo '<p><strong>' . $exhibitor_listing_county_parish['label'] . ':</strong> ' . $exhibitor_listing_county_parish['value'] . '</p>';
      }
      if( $exhibitor_listing_street ){
        echo '<p><strong>' . $exhibitor_listing_street['label'] . ':</strong> ' . $exhibitor_listing_street['value'] . '</p>';
      }
      if( $exhibitor_listing_no_of_wells ){
        echo '<p><strong>' . $exhibitor_listing_no_of_wells['label'] . ':</strong> ' . $exhibitor_listing_no_of_wells['value'] . '</p>';
      }
      if( $exhibitor_listing_well_count_potential ){
        echo '<p><strong>' . $exhibitor_listing_well_count_potential['label'] . ':</strong> ' . $exhibitor_listing_well_count_potential['value'] . '</p>';
      }
      if( $exhibitor_listing_no_of_prospects ){
        echo '<p><strong>' . $exhibitor_listing_no_of_prospects['label'] . ':</strong> ' . $exhibitor_listing_no_of_prospects['value'] . '</p>';
      }
      if( $exhibitor_listing_acreage ){
        echo '<p><strong>' . $exhibitor_listing_acreage['label'] . ':</strong> ' . $exhibitor_listing_acreage['value'] . '</p>';
      }



      if( $exhibitor_listing_gross_acres ){
        echo '<p><strong>' . $exhibitor_listing_gross_acres['label'] . ':</strong> ' . $exhibitor_listing_gross_acres['value'] . '</p>';
      }
      if( $exhibitor_listing_net_acres ){
        echo '<p><strong>' . $exhibitor_listing_net_acres['label'] . ':</strong> ' . $exhibitor_listing_net_acres['value'] . '</p>';
      }
      if( $exhibitor_listing_completion_date ){
        echo '<p><strong>' . $exhibitor_listing_completion_date['label'] . ':</strong> ' . $exhibitor_listing_completion_date['value'] . '</p>';
      }
      if( $exhibitor_listing_api_no ){
        echo '<p><strong>' . $exhibitor_listing_api_no['label'] . ':</strong> ' . $exhibitor_listing_api_no['value'] . '</p>';
      }
      if( $exhibitor_listing_legal_location_tsr_section ){
        echo '<p><strong>' . $exhibitor_listing_legal_location_tsr_section['label'] . ':</strong> ' . $exhibitor_listing_legal_location_tsr_section['value'] . '</p>';
      }
      if( $exhibitor_listing_field ){
        echo '<p><strong>' . $exhibitor_listing_field['label'] . ':</strong> ' . $exhibitor_listing_field['value'] . '</p>';
      }


      if( $exhibitor_listing_basin_play ){
        echo '<p><strong>' . $exhibitor_listing_basin_play['label'] . ':</strong> ' . $exhibitor_listing_basin_play['value'] . '</p>';
      }
      if( $exhibitor_listing_basin_trend ){
        echo '<p><strong>' . $exhibitor_listing_basin_trend['label'] . ':</strong> ' . $exhibitor_listing_basin_trend['value'] . '</p>';
      }
      if( $exhibitor_listing_objective_1 ){
        echo '<p><strong>' . $exhibitor_listing_objective_1['label'] . ':</strong> ' . $exhibitor_listing_objective_1['value'] . '</p>';
      }
      if( $exhibitor_listing_objective_1_depth_ft ){
        echo '<p><strong>' . $exhibitor_listing_objective_1_depth_ft['label'] . ':</strong> ' . $exhibitor_listing_objective_1_depth_ft['value'] . '</p>';
      }
      if( $exhibitor_listing_objective_1_expected_ip ){
        echo '<p><strong>' . $exhibitor_listing_objective_1_expected_ip['label'] . ':</strong> ' . $exhibitor_listing_objective_1_expected_ip['value'] . '</p>';
      }
      if( $exhibitor_listing_objective_2 ){
        echo '<p><strong>' . $exhibitor_listing_objective_2['label'] . ':</strong> ' . $exhibitor_listing_objective_2['value'] . '</p>';
      }


      if( $exhibitor_listing_objective_2_depth_ft ){
        echo '<p><strong>' . $exhibitor_listing_objective_2_depth_ft['label'] . ':</strong> ' . $exhibitor_listing_objective_2_depth_ft['value'] . '</p>';
      }
      if( $exhibitor_listing_objective_2_expected_ip ){
        echo '<p><strong>' . $exhibitor_listing_objective_2_expected_ip['label'] . ':</strong> ' . $exhibitor_listing_objective_2_expected_ip['value'] . '</p>';
      }
      if( $exhibitor_listing_comments_formations ){
        echo '<p><strong>' . $exhibitor_listing_comments_formations['label'] . ':</strong> ' . $exhibitor_listing_comments_formations['value'] . '</p>';
      }
      if( $exhibitor_listing_formation_1 ){
        echo '<p><strong>' . $exhibitor_listing_formation_1['label'] . ':</strong> ' . $exhibitor_listing_formation_1['value'] . '</p>';
      }
      if( $exhibitor_listing_formation_1_depth_ft ){
        echo '<p><strong>' . $exhibitor_listing_formation_1_depth_ft['label'] . ':</strong> ' . $exhibitor_listing_formation_1_depth_ft['value'] . '</p>';
      }
      if( $exhibitor_listing_formation_2 ){
        echo '<p><strong>' . $exhibitor_listing_formation_2['label'] . ':</strong> ' . $exhibitor_listing_formation_2['value'] . '</p>';
      }

      if( $exhibitor_listing_formation_2_depth_ft ){
        echo '<p><strong>' . $exhibitor_listing_formation_2_depth_ft['label'] . ':</strong> ' . $exhibitor_listing_formation_2_depth_ft['value'] . '</p>';
      }




    }


	wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'the7mk2' ), 'after' => '</div>' ) );
	echo '</div>';

	// Post meta.
	$post_meta = presscore_get_single_posted_on();
	if ( $config->get( 'post.meta.fields.tags' ) ) {
		$post_meta .= presscore_get_post_tags_html();
	}

	if ( $post_meta ) {
		echo '<div class="post-meta wf-mobile-collapsed">' . $post_meta . '</div>';
	}

	presscore_display_share_buttons_for_post( 'post' );

	if ( $config->get( 'post.author_block' ) ) {
		presscore_display_post_author();
	}

	echo presscore_new_post_navigation();

	presscore_display_related_posts();

	do_action( 'presscore_after_post_content' );
	?>

</article>